from project.climbers.base_climber import BaseClimber
from project.peaks.base_peak import BasePeak


class SummitClimber(BaseClimber):
    INITIAL_STRENGTH = 150
    FATIGUE = 30

    def __init__(self, name: str):
        super().__init__(name, strength=self.INITIAL_STRENGTH)

    def can_climb(self):
        if self.strength >= 75:
            return True
        return False

    def climb(self, peak: BasePeak):
        if peak.difficulty == 'Advanced':
            self.strength -= self.FATIGUE * 1.3
        else:
            self.strength -= self.FATIGUE * 2.5
        self.conquered_peaks.append(peak.name)